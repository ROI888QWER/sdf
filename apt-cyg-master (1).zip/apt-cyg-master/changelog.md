2013-10-23
----------

* [b29ec29](http://github.com/transcode-open/apt-cyg/commit/b29ec29)
  Added multiarch support
* [9058643](http://github.com/transcode-open/apt-cyg/commit/9058643)
  Added xz archives support
